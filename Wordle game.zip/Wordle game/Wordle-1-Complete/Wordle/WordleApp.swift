//
//  WordleApp.swift
//  Wordle
//
//  Created by Stewart Lynch on 2022-01-19.
//

import SwiftUI

@main
struct WordleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
